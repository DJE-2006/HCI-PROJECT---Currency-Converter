document.addEventListener('DOMContentLoaded', function() {
    const themeToggleBtn = document.getElementById('theme-toggle-btn');
    const body = document.body;
    
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        body.classList.remove('light-mode');
        body.classList.add('dark-mode');
        themeToggleBtn.innerHTML = '☀️';
    }
    
    themeToggleBtn.addEventListener('click', function() {
        if (body.classList.contains('light-mode')) {
            body.classList.remove('light-mode');
            body.classList.add('dark-mode');
            themeToggleBtn.innerHTML = '☀️';
            localStorage.setItem('theme', 'dark');
        } else {
            body.classList.remove('dark-mode');
            body.classList.add('light-mode');
            themeToggleBtn.innerHTML = '🌙';
            localStorage.setItem('theme', 'light');
        }
    });
    
    const navLinks = document.querySelectorAll('.nav-link');
    const pageSections = document.querySelectorAll('.page-section');

    function showPage(pageId) {
        pageSections.forEach(section => {
            section.classList.remove('active-section');
        });
        
        document.getElementById(pageId + '-section').classList.add('active-section');
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('data-page') === pageId) {
                link.classList.add('active');
            }
        });
    }
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const pageId = this.getAttribute('data-page');
            showPage(pageId);
        });
    });
    
    const getStartedBtn = document.getElementById('get-started-btn');
    if (getStartedBtn) {
        getStartedBtn.addEventListener('click', function(e) {
            e.preventDefault();
            showPage('converter');
        });
    }
    
    const convertBtn = document.getElementById('convert-btn');
    if (convertBtn) {
        convertBtn.addEventListener('click', convertCurrency);
    }
    
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactFormSubmit);
    }
});

function convertCurrency() {
    const amount = document.getElementById('amount').value;
    const fromCurrency = document.getElementById('from-currency').value;
    const toCurrency = document.getElementById('to-currency').value;
    const resultElement = document.getElementById('result');
    
    if (!amount || isNaN(amount) || amount <= 0) {
        resultElement.textContent = 'Please enter a valid amount';
        return;
    }
    
    const exchangeRates = {
        USD: 1.00,
        EUR: 0.85,
        GBP: 0.73,
        JPY: 110.42,
        CAD: 1.25,
        AUD: 1.35,
        CHF: 0.92,
        CNY: 6.47,
        INR: 74.38,
        BRL: 5.25
    };
    
    const convertedAmount = (amount / exchangeRates[fromCurrency]) * exchangeRates[toCurrency];
    
    const formattedResult = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: toCurrency,
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(convertedAmount);
    
    resultElement.textContent = `${amount} ${fromCurrency} = ${formattedResult}`;
}

function handleContactFormSubmit(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;
    
    if (!name || !email || !message) {
        alert('Please fill in all fields');
        return;
    }
    
    alert(`Thank you, ${name}! Your message has been sent successfully.`);
    
    event.target.reset();
}

async function convertCurrency() {
    const amount = parseFloat(document.getElementById('amount').value);
    const fromCurrency = document.getElementById('from-currency').value;
    const toCurrency = document.getElementById('to-currency').value;

    if (isNaN(amount)) {
        document.getElementById('result').innerText = "Please enter a valid amount.";
        return;
    }

    document.getElementById('result').innerText = "Fetching conversion rates...";
    try {
        const apiKey = '6664dc7cf26da11de3b59c1c';
        const response = await fetch(`https://v6.exchangerate-api.com/v6/${apiKey}/latest/${fromCurrency}`);
        const data = await response.json();

        if (response.ok && data.result === "success") {
            const rate = data.conversion_rates[toCurrency];
            const convertedAmount = (amount * rate).toFixed(2);
            document.getElementById('result').innerText = `${amount} ${fromCurrency} = ${convertedAmount} ${toCurrency}`;
        } else {
            document.getElementById('result').innerText = "Error fetching conversion rates.";
        }
    } catch (error) {
        document.getElementById('result').innerText = "An error occurred. Please try again.";
        console.error(error);
    }
}